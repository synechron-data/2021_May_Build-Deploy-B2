// Variables created are optionally typesafe
// Untyped Variable = No Type Safety, No Intellisense (any)
// var data1;
// data1 = 10;
// data1 = "abc";

// Implicitly Typed
// var data2 = 10;
// data2 = "abc";       // Compile Time Error: Type 'string' is not assignable to type 'number'.

// var data3 = "manish";
// data3 = 10;             // Compile Time Error: Type 'number' is not assignable to type 'string'

// Explicitly Typed
// var age: number;
// age = 10;
// age = "abc";            // Compile Time Error: Type 'string' is not assignable to type 'number'.

// var city: string;
// city = "Pune";

// Function to add 2 numbers
// function add(x, y) {                // Error: Parameter 'x' implicitly has an 'any' type. ,  Parameter 'y' implicitly has an 'any' type.
//     return x + y;
// }

// function add(x: any, y: any) {
//     return x + y;
// }

function add(x: number, y: number) {
    return x + y;
}

console.log(add(2, 3));
// console.log(add(2, "ABC"));
// console.log(add("ABC", "XYZ"));

// var s: symbol = Symbol("Hello");

// JAVASCRIPT Types and API's
// number / string / boolean / undefined / Array / Object / Date / RegExp / Function / void
// Based on target and lib section configured in tsconfig.json

// TypeScript Types
// any / never / tuple / enum / interface / class / typeguards