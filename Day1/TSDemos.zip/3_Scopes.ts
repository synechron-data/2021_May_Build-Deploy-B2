// Global Scope
// Local Scope (Function Scope)
// Block Scope (Using let and const keyword)

// var i = 10;
// var i = 20;
// console.log(i);

// Support Hosting - Moving Declarations to the top
// a = "Hi";
// console.log(a);
// var a;

// var i = 20;

// // function test() {
// //     var i = "Hello";
// //     console.log("Inside Function: ", i);
// // }

// function test() {
//     if (true) {
//         var i = "Hello";
//         console.log("Inside If Block: ", i);
//     }
//     console.log("Inside Function: ", i);
// }

// test();
// console.log("Outside Function: ", i);

// var i = 100;
// console.log("Before, i is", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside, i is", i);
// }

// for (var _i = 0; _i < 5; _i++) {
//     console.log("Inside, i is", _i);
// }

// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside, i is", i);
//     }
// })();

// console.log("After, i is", i);

// ---------------------------------------------------------------- let (To Create Block Scoped Variable)
// let i = 10;
// let i = 20;                     // Cannot redeclare block-scoped variable 'i'.
// console.log(i);

// Does not Support Hosting
// a = "Hi";
// console.log(a);
// let a;

var i = 100;
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside, i is", i);
}

console.log("After, i is", i);