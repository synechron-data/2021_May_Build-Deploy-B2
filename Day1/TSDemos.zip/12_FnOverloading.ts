// function hello() {
//     console.log("Hello World");
// }

// // Error : Duplicate function implementation.
// function hello(name) {
//     console.log("Hi,", name);
// }

// hello();
// hello("Manish");

// --------------------------------------------------------------
// function hello(): void;
// function hello(name: string): void;

// function hello(...args: string[]) {
//     if (args.length === 0)
//         console.log("Hello World");
//     else if (args.length === 1)
//         console.log("Hi,", args[0]);
//     else
//         throw new Error("Invalid Number of Arguments");
// }

// hello();
// hello("Synechron");
// hello("Synechron", "Pune");

// function test(x: string, y: number): void;
// function test(x: string, y: string): void;

// function test(x: any, y: any) {

// }

// test("Manish", 1);
// test("Manish", "Sharma");

// ------------------------------------------------------------- Assignment
// Create a function Reverse which can accept string or array of any 
// type and give the following output

// console.log(Reverse("Manish"));                 // [ 'h', 's', 'i', 'n', 'a', 'M' ]
// console.log(Reverse(["PQR", "XYZ", "ABC"]));    // [ 'ABC', 'XYZ', 'PQR' ]
// console.log(Reverse([10, 20, 30, 40]));         // [ 40, 30, 20, 10 ]
// console.log(Reverse(10));                       // Compile time Error