function hello(name) {
    console.log("Hello,", name);
}

hello("Manish");
hello("Abhijeet", "Pune");
hello();