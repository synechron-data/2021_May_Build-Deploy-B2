function hello() {
    console.log("Hello World");
}

function hello(name) {
    console.log("Hi,", name);
}

hello();
hello("Manish");