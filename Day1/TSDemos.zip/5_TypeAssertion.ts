// Type assertion is a mechanism which tells the compiler about the type of a variable. 
// Type assertion is explicitly telling the compiler that we want to treat the entity as a different type.

var data: any = "Hello, I am a string";

console.log(data);
console.log(typeof data);
// console.log(data.toUppercase());         // Runtime Error: c in case is capital C - toUpperCase()
// console.log(data.toUpperCase()); 

// console.log((<string>data).toUpperCase());
// console.log((data as string).toUpperCase());

// var a1 = data.length;
// console.log(a1);

// var a2 = (<string>data).length;
// console.log(a2);

// var a3 = (data as string).length;
// console.log(a3);

// var a4 = (data as number).toFixed();
// console.log(a4);