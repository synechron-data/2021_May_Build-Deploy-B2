// var x = 10;

// console.log(x);
// console.log(typeof x);

// var f = function () {
//     console.log("Hello");
// }

// console.log(f);
// console.log(typeof f);

// // Can you create a variable of type number?
// // Yes, we should be able to create a variable of type function also.

// // Can you create a variable of type number inside a function?
// // Yes, we should be able to create a variable of type function inside a function also. (Nested Function)

// // Can you return a variable of type number from a function?
// // Yes, we should be able to resturn a variable of type function from a function also. (Closure/Fn Currying)

// // Can you pass a variable of type number to a function?
// // Yes, we should be able to pass a variable of type function to a function also. (Callbacks)

// --------------------------------------------------------------------------------------------

// document.getElementById("btn").addEventListener("click", function (e) {
// });

// setInterval(function () {
//     console.log("Hello");
// }, 2000);

let employees = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Ramakant", city: "Delhi" },
    { id: 3, name: "Abhijeet", city: "Pune" },
    { id: 4, name: "Pravin", city: "Mumbai" },
    { id: 5, name: "Subodh", city: "Pune" }
];

// var pune_employees = [];

// for (let i = 0; i < employees.length; i++) {
//     if (employees[i].city === "Pune") {
//         pune_employees.push(employees[i]);
//     }
// }

// console.log(pune_employees);

// ----------------------------------------------------------------
// var pune_employees = [];

// function filterLogic(item: { id: number, name: string, city: string }) {
//     return item.city === "Pune";
// }

// for (let i = 0; i < employees.length; i++) {
//     if (filterLogic(employees[i])) {
//         pune_employees.push(employees[i]);
//     }
// }

// console.log(pune_employees);

// ----------------------------------------------------------------

// function filterLogic(item: { id: number, name: string, city: string }) {
//     return item.city === "Pune";
// }

// var pune_employees = employees.filter(filterLogic);
// console.log(pune_employees);

// ----------------------------------------------------------------

// var pune_employees = employees.filter(function (item) {
//     return item.city === "Pune";
// });
// console.log(pune_employees);

// ----------------------------------------------------------------

// var pune_employees = employees.filter((item) => {
//     return item.city === "Pune";
// });
// console.log(pune_employees);

// ----------------------------------------------------------------

var pune_employees = employees.filter(item => item.city === "Pune");
console.log(pune_employees);