// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// // class Person implements IPerson {
// //     name: string;
// //     age: number;

// //     constructor(n: string, a: number) {
// //         this.name = n;
// //         this.age = a;
// //     }

// //     greet(message: string): string {
// //         return "Hello";
// //     }
// // }

// class Person implements IPerson {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }
// }

// let p1: IPerson = new Person("Abhijeet", 38);
// let p2: IPerson = new Person("Ramakant", 38);

// console.log(p1.greet("Hi"));
// console.log(p2.greet("Hi"));

// -------------------------------------------------------- Multiple Interface Implementation
// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee {
//     doWork(): string;
// }

// class Person implements IPerson, IEmployee {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript"
//     }
// }

// let p1: Person = new Person("Abhijeet", 38);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// -------------------------------------------------------- Interface Extraction
// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee {
//     doWork(): string;
// }

// interface ICustomer {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript"
//     }

//     doShopping(): string {
//         return "Let us do it online";
//     }
// }

// let p1: Person = new Person("Abhijeet", 38);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());
// console.log(p1.doShopping());

// // Interface Extraction
// let p2: IPerson = new Person("Abhijeet", 38);
// console.log(p2.greet("Hi"));

// let p3: IEmployee = new Person("Abhijeet", 38);
// console.log(p3.doWork());

// let p4: ICustomer = new Person("Abhijeet", 38);
// console.log(p4.doShopping());

// -------------------------------------------------------- Interface can extend Other Interface(s)
// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee extends IPerson {
//     doWork(): string;
// }

// interface ICustomer extends IPerson {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript"
//     }

//     doShopping(): string {
//         return "Let us do it online";
//     }
// }

// let p1: IEmployee = new Person("Abhijeet", 38);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// let p2: ICustomer = new Person("Abhijeet", 38);
// console.log(p2.greet("Hi"));
// console.log(p2.doShopping());

// -------------------------------------------------------- Interface can extend from class(s)

// class Developer {
//     applyLeave() {
//         console.log("Apply Leave");
//     }
// }

// class Manager {
//     applyLeave() {
//         console.log("Apply Leave");
//     }

//     approveLeave() {
//         console.log("Approve Leave of Team");
//     }
// }

// interface IDevMan {
//     applyLeave(): void;
//     approveLeave(): void;
// }

// interface IDevMan extends Developer, Manager { }

// class DevManager implements IDevMan {
//     applyLeave(): void {
//         throw new Error("Method not implemented.");
//     }
//     approveLeave(): void {
//         throw new Error("Method not implemented.");
//     }
// }