// Create a function Reverse which can accept string or array of any 
// type and give the following output

function Reverse(word: string): string[];
function Reverse(words: string[]): string[];
function Reverse(numbers: number[]): number[];

// function Reverse(strOrArr: any): any {
//     if (typeof strOrArr === "string")
//         return strOrArr.split("").reverse();
//     else
//         return strOrArr.reverse();
// }

// function Reverse(strOrArr: any): any {
//     if (typeof strOrArr === "string")
//         return strOrArr.split("").reverse();
//     else
//         return (<Array<any>>strOrArr).reverse();
// }

// TypeGuard
// var data: number | string | boolean;
// data = 10;
// data = "abc";

function Reverse(strOrArr: string | any[]): any[] {
    if (typeof strOrArr === "string")
        return strOrArr.split("").reverse();
    else
        return strOrArr.reverse();
}

console.log(Reverse("Manish"));                 // [ 'h', 's', 'i', 'n', 'a', 'M' ]
console.log(Reverse(["PQR", "XYZ", "ABC"]));    // [ 'ABC', 'XYZ', 'PQR' ]
console.log(Reverse([10, 20, 30, 40]));         // [ 40, 30, 20, 10 ]
// console.log(Reverse(10));                       // Compile time Error
